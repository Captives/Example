let mysql = require('mysql');
let sql = require('./../conf/conf').sql;
var log4js = require('./../conf/Logger');
var console = log4js.getLogger('db');
let options = {
    host: sql.host,
    port: sql.port,
    user: sql.user,
    password: sql.password,
    database: sql.database
};

let connection = mysql.createConnection(options);

let ready = () => {
    return new Promise((resolve, reject) => {
        if (connection.state !== "disconnected") {
            resolve(connection);
        }
        connection.connect(function (error) {
            if (error) {
                console.log("数据库已经断开,5秒后开始重连...");
                setTimeout(e => {
                    ready().then(resolve).catch(reject)
                }, 5000);//5s断线重连
            } else {
                resolve(connection);
            }
        });
    });
};

let query = (sql, params) => {
    return new Promise((resolve, reject) => {
        console.log("SQL ::", sql, params);
        connection.query(sql, params, (error, result) => {
            if (error) {
                console.log("## 异常 >>>", error.message);
                reject(error.message);
            } else {
                resolve(result);
            }
        });
    });
};

let close = () => {
    return new Promise((resolve, reject) => {
        connection.end(function (error) {
            if (error) {
                reject(error);
            }
            console.log('[connection end] succeed!');
        });
    });
};

module.exports = {
    ready: ready,
    query: query,
    close: close
};