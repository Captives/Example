/**
 * Created by Administrator on 2017/6/22.
 */
var db = require('./DataBase');
var log4js = require('./../conf/Logger');
var console = log4js.getLogger('db');
//插入一个用户
let insert = (classId, userid, username, userphoto) => {
    return new Promise((resolve, reject) => {
        var sql = "INSERT INTO userinfo(classid, userid, username, photo, dia, ub, muted, drawing) VALUES (?,?,?,?,0,0,0,1)";
        var params = [classId, userid, username, userphoto];
        db.query(sql, params).then(resolve).catch(reject);
    });
}

//查询
let search = (classId, userid) => {
    return new Promise((resolve, reject) => {
        var sql = "SELECT * FROM userinfo WHERE classid = ?";
        var params = [classId];
        if (userid) {
            sql += " and userid = ?";
            params.push(userid);
        }
        db.query(sql, params).then(resolve).catch(reject);
    });
}

//更新一个用户
let update = (classId, userid, dia, ub, muted, drawing, team, position) => {
    return new Promise((resolve, reject) => {
        var sql = "UPDATE userinfo SET dia = ?, ub = ?, muted = ? , drawing = ?, team = ?, position = ? WHERE classid = ?";
        var params = [dia, ub, muted, drawing, team, position, classId];
        if(userid){
            sql +=" and userid = ?";
            params.push(userid);
        }
        db.query(sql, params).then(resolve).catch(reject);
    });
}

//--------------------------------------------------  业务  ------------------------------------------
//加入一个用户
let addUser = (classId, userid, username, userphoto) => {
    return new Promise((resolve, reject) => {
        search(classId, userid).then(result => {
            if (result.length == 0) {
                insert(classId, userid, username, userphoto).then(result => {
                    //查询输出下
                    search(classId, userid).then(resolve).catch(reject);
                }).catch(reject);
            } else {
                console.log("数据库已经存在",JSON.stringify( result ));
                //查询已经存在的,查询输出下
                resolve(result);
            }
        }).catch(reject);
    });
};

//更新用户的数据
let updateUser = (classId, userid, dia, ub, muted, drawing, team, position) => {
    return new Promise((resolve, reject) => {
        search(classId, userid).then(result => {
            if (result.length == 0) {
                reject("不存在的用户");
            } else {
                var data = result[0];
                data.dia = dia == null ? data.dia : dia;
                data.ub = ub == null ? data.ub : ub;
                data.muted = muted == null ? data.muted : muted;
                data.drawing = drawing == null ? data.drawing : drawing;
                data.team = team == null ? data.team : team;
                data.position = position == null ? data.position : position;
                update(classId, userid, data.dia, data.ub, data.muted, data.drawing, data.team, data.position).then(resolve).catch(reject);
            }
        }).catch(reject);
    });
};

//查询一个学生或指定班内的学生
let searchUser = (classid, userid) => {
    return new Promise((resolve, reject) => {
        search(classid, userid).then(function (result) {
            resolve(result);
        }).catch(reject);
    });
};

/**
 *  指定课程随机分组,最小2组,每组最少2个人
 * @param classid   课程id
 * @param count     随机分组
 * @returns {Promise}
 */
let getTeam = (classid, count) => {
    count = count || 2;
    return new Promise((resolve, reject)=> {
        search(classid).then(result => {
            if (result.length < count * 2) {
                resolve(result);
            } else {
                if (result > count * 2 && result[0].team) {
                    resolve(result);//大于,但是有值
                } else {
                    let label = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];//最大支持10组
                    let updatelist = [];    //所有update事件
                    result.forEach((item, index) => {
                        let team = index % count;
                        label[team]++;
                        let pos = label[team];
                        updatelist.push(updateUser(classid, item['userid'], null, null, null, null, team, pos));
                    });

                    Promise.all(updatelist).then(result => {
                        search(classid).then(resolve).catch(reject);
                    }).catch(reject);
                }
            }
        }).catch(reject);
    });
};

/**
 * 放入一个用户,如果超过4个人,则分成2组
 * @param classId
 * @param userid
 * @param username
 * @param userphoto
 * @returns {*}
 */
let push = (classId, userid, username, userphoto) => {
    return new Promise((resolve, reject) => {
        addUser(classId, userid, username, userphoto).then(info => {
            search(classId).then(result => {
                if (result.length >= 4) {
                    getTeam(classId, 2).then(resolve).catch(reject);
                } else {
                    resolve(result);
                }
            }).catch(reject);
        }).catch(reject);
    });
};

//--------------------------------------------------  业务 END  ----------------------------------------
let User = {
    Add: push,
    Search: searchUser,
    Update: updateUser,
    GetTeam: getTeam,
};
module.exports = User;

setTimeout(e=> {
    User.Search(1090, 11).then(info =>{
        console.log(info[0].username);
    }).catch(error => {
        console.log(error);
    });
    // User.Update(1090,15,null,502, 0, 155).then(info =>{
    //     console.log(info);
    // }).catch(error => {
    //     console.log(error);
    // });
    //
    User.Search(1090, 15).then(result => {
        result.forEach(function (user) {
            console.log(JSON.stringify(user));
        });
    }).catch(error => {
        console.log(error);
    });

    // User.GetTeam(1090, 3).then(result=>{
    //     result.forEach(function (user) {
    //         console.log(JSON.stringify(user));
    //     });
    // }).catch(err => {
    //     console.log(err.message);
    // });
    // User.Search(1090,11).then(result => {
    //     console.log("执行完成",result.length);
    //     result.forEach(function (user) {
    //         console.log(JSON.stringify(user));
    //     });
    // }).catch(error => {
    //     console.log(error);
    // });
}, 3000);